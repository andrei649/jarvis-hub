# Restore archive — the development gates removed from jarvis-hub

**What this is:** everything PR [#981](https://github.com/andrei649/jarvis-hub/pull/981)
deleted or changed when the owner de-gated the development workflow, packaged so any part
of it can be brought back later.

| | |
|---|---|
| Repo | `andrei649/jarvis-hub` |
| De-gating commit | `824ff18` (squash of PR #981, merged 2026-08-30 09:09 UTC) |
| Last commit with all gates present | `5e6e184` (= `824ff18^`) |
| **Patches apply to** | **`7eb8772`** — see *If a patch stops applying* below if `main` has moved |
| Scope | 58 files — **30 deleted**, 28 modified · **25,629 lines removed** |

Applying `restore-ALL.patch` reproduces the pre-de-gating state **byte-identically for 57
of the 58 paths**. The 58th is `BACKLOG.md`, where the restore reverts only the de-gating
annotation and preserves the 373 lines PR #983 added afterward — a restore must not clobber
later work.

---

## Restore everything

`git apply` resolves the patch path relative to your **current directory**, and this archive
lives outside the repo tree — so set `$ARCHIVE` to wherever you unzipped it and use that.

```bash
unzip docs/restore/dev-gates-restore-2026-08-30.zip -d /tmp/restore
ARCHIVE=/tmp/restore/nerva-gates-restore-2026-08-30

cd /path/to/jarvis-hub
git checkout -b restore/dev-gates
git apply "$ARCHIVE/restore-ALL.patch"
git add -A && git commit -m "revert: restore the development gates removed in #981"
```

## Restore one gate only (the usual case)

```bash
git apply "$ARCHIVE/groups/A-security-scans.patch"     # just the security scans
```

Stack as many as you want — no two groups touch the same file, so the patches never conflict
with each other and application order does not matter. **But two groups are functionally
coupled** (see below), so choose *which* groups you restore with that in mind.

## If a patch stops applying

These patches were cut against `7eb8772`. Once `main` drifts, context lines move:

```bash
git apply -3 "$ARCHIVE/restore-ALL.patch"   # 3-way merge; resolve conflicts normally
```

Every diff carries its blob index lines, so `-3` always has what it needs. For any of the
30 **deleted** files there is a simpler escape hatch — they were deleted outright, so there
is nothing to merge and you can just copy them in:

```bash
cp "$ARCHIVE/deleted-files/.github/workflows/security.yml" .github/workflows/
```

---

## The groups

| Group | Restores | Lines | PR checks it re-adds |
|---|---|--:|---|
| **A** `security-scans` | gitleaks, semgrep, pip-audit, bandit — all four **blocking** | 6,985 | `Secret scan (gitleaks)`, `SAST (semgrep)`, `Dependency audit (pip-audit)`, `SAST (bandit — blocking gate)` |
| **B** `ai-review` | 3 AI reviewers per PR | 79 | `review (correctness)`, `review (boundary)`, `review (tests)` |
| **C** `autonomy-boundary` | tier classifier that holds "loosening" PRs for you, + per-PR auto-merge enable | 590 | `boundary`, `auto-merge` |
| **D** `nerva-movement-roadmap` | roadmap/ledger validation + all `check_nerva_*` scripts and tests — **the big one** | 16,393 | `validate` |
| **E** `lockfile-drift` | fails a PR that edits `requirements*.txt` without regenerating the lock | 35 | `in-sync` |
| **F** `park-guard` | blocks PRs touching parked modules without an approved unpark | 48 | `parked-modules` |
| **G** `pre-commit-hooks` | local commit hooks: gitleaks, ruff, EOF fixer, large-file check | 32 | *(local only)* |
| **H** `ai-policy-pr-template` | R0–R3 risk policy + checker, evidence-receipt PR template, AGENTS.md ceremony | 1,314 | *(process only)* |
| **I** `codeowners` | owner review required on `.github/` and the gate scripts | 14 | *(needs branch protection)* |
| **J** `ci-full-pr-matrix` | puts Windows + sandbox + frontend + HUD + OpenAPI lanes **back on the PR path**, and the `nerva-movement` job | 72 | `test (windows-latest)`, `nerva-movement`, `sandbox-isolation`, `signal-layer-smoke (ubuntu-latest)`, `signal-layer-smoke (windows-latest)`, `frontend`, `hud-v2-build`, `openapi-types` |
| **K** `pr-triggers-7-workflows` | re-adds `pull_request:` to CodeQL, code-health, e2e, eval-nightly, smoke, thirdparty-drift, worldview | 45 | `Analyze (python)`, `analyze`, `e2e`, `server-boot`, `drift`, `companion-gate`, `nerva-router-shadow`, `nerva-lesson-held-out`, `Ingestion workers (Python)`, `API + Frontend (Node)`, `MCP server (Node)`, `Integration (TimescaleDB + Redis)` |
| **L** `docs-and-counters` | the prose: "CI must be green before merging", maintainer review, no-direct-push, the OWNER_TASKS de-gate checklist, test counter 6832→7089 | 22 | — |

Group **J** is what makes PRs slow again — it moves the 20-minute `test (windows-latest)`
lane plus five other jobs off post-merge and back onto the PR critical path.

`MANIFEST.json` carries every check name in full, machine-readable, if you want to script the
branch-protection update.

### Dependencies between groups

- **D and J need each other — restore them together.** J's `nerva-movement` job runs
  `scripts/check_nerva_issue_movement.py`, which lives in D: without D the job exists but
  fails on a missing script. In the other direction, three tests in D's
  `tests/test_nerva_issue_movement.py` read the real `.github/workflows/ci.yml` and assert
  the `nerva-movement` job, `test.needs == ["nerva-movement"]` and the two-OS matrix — so
  restoring D without J gives you three failing tests. If you want only one of them: restore
  J and delete its `nerva-movement` job, or restore D and delete those three tests
  (`test_ci_nerva_movement_is_pr_only_exact_head_and_uses_live_checker`,
  `test_ci_test_matrix_fails_before_setup_when_pr_movement_fails`,
  `test_ci_movement_permissions_are_read_only_and_runs_are_static`).
- **G degrades without A (soft).** The pre-commit gitleaks hook runs
  `gitleaks git --pre-commit --redact --staged` with no `--config`, so it auto-discovers
  `.gitleaks.toml`, which lives in A. Without A the hook still runs — gitleaks logs
  *"no gitleaks config found … using default gitleaks config"* — but loses the allowlist for
  `tests/`, `docs/` and `stark_ga4_property_id`, so commits touching fixtures will trip false
  positives. Restore A alongside G unless you want the default ruleset.

No other cross-group coupling exists: H, F and C are self-contained, and K's workflows are
read by surviving tests that assert nothing about triggers.

---

## The other half: GitHub branch protection

**Patches only restore files.** A restored workflow will run and post its check, but it
cannot *block* a merge until that check is marked required again under
**Settings → Branches / Rules for `main` → Require status checks to pass**. Re-add only the
check names from the groups you restored (the table above, or `MANIFEST.json`).

The same applies to **Require review from Code Owners** (group I) and the CodeQL
merge-protection ruleset (group K).

While nothing is required, the hourly `pr-auto-merge.yml` sweep squash-merges any non-draft
PR GitHub reports as clean — keep work-in-progress as drafts.

---

## What was NOT removed (don't go looking for it here)

- **Runtime/product security** — API auth, the token store, sandbox containment,
  path-traversal guards, CSP headers. Untouched; only development-process gates were removed.
- **Kept automation** — `pr-auto-merge.yml`, the `@claude` bot, release, soak, reality,
  nightly evals, Dependabot, hash-pinned lockfiles.
- **`scripts/park_guard.py`** and **`scripts/lock_deps.sh`** — the scripts survived; only
  their CI enforcement workflows were deleted (groups F and E).
- **The heavy test lanes** — Windows tests, sandbox isolation, frontend/HUD suites, OpenAPI
  drift and CodeQL still run, just post-merge on `main` or on a schedule. Groups J and K move
  them back onto PRs.

---

## Files in this archive

```
00-README.md                 this file
MANIFEST.json                machine-readable: every group, path, line count, check name
restore-ALL.patch            restores all 58 paths at once
groups/*.patch               12 independent per-gate patches
deleted-files/               pristine full copies of all 30 deleted files, byte-identical
                             to their state at 824ff18^ (copy in directly, no patching)
```
