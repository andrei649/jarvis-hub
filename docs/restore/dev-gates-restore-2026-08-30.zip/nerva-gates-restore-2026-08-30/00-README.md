# Restore archive — the development gates removed from jarvis-hub

**What this is:** everything PR [#981](https://github.com/andrei649/jarvis-hub/pull/981)
deleted or changed when the owner de-gated the development workflow, packaged so any part
of it can be brought back later.

| | |
|---|---|
| Repo | `andrei649/jarvis-hub` |
| De-gating commit on `main` | `824ff18` (squash of PR #981, merged 2026-08-30 09:09 UTC) |
| State with all gates present | `824ff18^` = `5e6e184` |
| Scope | 58 files — **30 deleted**, 28 modified · **25,629 lines removed** |

Every patch here was verified to apply cleanly to `main` as of `38a9903`, and applying
`restore-ALL.patch` reproduces the pre-de-gating state **byte-identically** for 57 of the
58 paths. The 58th is `BACKLOG.md`, where the restore correctly reverts only the de-gating
annotation and preserves the 373 lines PR #983 added afterward.

---

## Restore everything

```bash
cd /path/to/jarvis-hub
git checkout -b restore/dev-gates
git apply 00-restore/restore-ALL.patch
git add -A && git commit -m "revert: restore the development gates removed in #981"
```

If `main` has moved far enough that the patch conflicts, use a 3-way merge instead —
it resolves against the current content rather than requiring exact context:

```bash
git apply -3 restore-ALL.patch     # then resolve any conflicts normally
```

## Restore one gate only (the usual case)

Each file in `groups/` is independent. To bring back just the security scans:

```bash
git apply groups/A-security-scans.patch
```

Stack as many as you want. Order does not matter — no two groups touch the same file.

---

## The groups

| Group | Restores | Lines | PR checks it re-adds |
|---|---|--:|---|
| **A** `security-scans` | gitleaks, semgrep, pip-audit, bandit — all four **blocking** | 6,985 | `Secret scan (gitleaks)`, `SAST (semgrep)`, `Dependency audit (pip-audit)`, `SAST (bandit — blocking gate)` |
| **B** `ai-review` | 3 AI reviewers per PR (correctness / boundary / tests) | 79 | `review (correctness)`, `review (boundary)`, `review (tests)` |
| **C** `autonomy-boundary` | tier classifier that holds "loosening" PRs for you, + per-PR auto-merge enable | 590 | `boundary`, `auto-merge` |
| **D** `nerva-movement-roadmap` | roadmap/ledger validation + all `check_nerva_*` scripts and tests — **the big one** | 16,393 | `validate` |
| **E** `lockfile-drift` | fails a PR that edits `requirements*.txt` without regenerating the lock | 35 | `in-sync` |
| **F** `park-guard` | blocks PRs touching parked modules without an approved unpark | 48 | `parked-modules` |
| **G** `pre-commit-hooks` | local commit hooks: gitleaks, ruff, EOF fixer, large-file check | 32 | *(local only)* |
| **H** `ai-policy-pr-template` | R0–R3 risk policy, its checker, the evidence-receipt PR template, AGENTS.md ceremony | 1,314 | *(process only)* |
| **I** `codeowners` | owner review required on `.github/` and the gate scripts | 14 | *(needs branch protection)* |
| **J** `ci-full-pr-matrix` | puts Windows + sandbox + frontend + HUD + OpenAPI lanes **back on the PR path**, and the `nerva-movement` job | 72 | `test (windows-latest)`, `nerva-movement`, `sandbox-isolation`, `signal-layer-smoke (…)`, `frontend`, `hud-v2-build`, `openapi-types` |
| **K** `pr-triggers-7-workflows` | re-adds `pull_request:` to CodeQL, code-health, e2e, eval-nightly, smoke, thirdparty-drift, worldview | 45 | `Analyze (python)`, `analyze`, `e2e`, `server-boot`, `drift`, eval + worldview jobs |
| **L** `docs-and-counters` | the prose: "CI must be green before merging", maintainer review, no-direct-push, OWNER_TASKS de-gate checklist, test counter 6832→7089 | 22 | — |

**Two dependencies to know about:**

- **G needs A.** The pre-commit gitleaks hook reads `.gitleaks.toml`, which lives in group A.
- **J's `nerva-movement` job needs D.** That job runs `scripts/check_nerva_issue_movement.py`;
  without group D the job exists but fails on a missing script. Restore D alongside J, or
  delete the `nerva-movement` job from `ci.yml` after applying J.

Group J is also what makes PRs slow again: it is the 20-minute `test (windows-latest)` lane
plus five more jobs moving off post-merge and back onto the PR critical path.

---

## The other half: GitHub branch protection

**Patches only restore files.** A restored workflow will run and post its check, but it
cannot *block* a merge until the check is marked required again in
**Settings → Branches / Rules for `main` → Require status checks to pass**.

Add back only the check names from the groups you restored (the table above lists them
per group). Same for **Require review from Code Owners**, which group I depends on, and
the CodeQL merge-protection ruleset if you restore K.

Also worth knowing: while nothing is required, the hourly `pr-auto-merge.yml` sweep
squash-merges any non-draft PR GitHub reports as clean. Keep work-in-progress as drafts,
or restore the gates you want it to respect first.

---

## What was NOT removed (don't go looking for it here)

- **Runtime/product security** — API auth, the token store, sandbox containment, path-traversal
  guards, CSP headers. Untouched; only development-process gates were removed.
- **Kept automation** — `pr-auto-merge.yml`, the `@claude` bot, release, soak, reality,
  nightly evals, Dependabot, hash-pinned lockfiles.
- **`scripts/park_guard.py`** and **`scripts/lock_deps.sh`** — the scripts survived; only
  their CI enforcement workflows were deleted (groups F and E).
- **The post-merge lanes** — Windows tests, sandbox isolation, frontend/HUD suites, OpenAPI
  drift and CodeQL still run, just on `main` after merge or on a schedule. Group J/K move
  them back onto PRs.

---

## Files in this archive

```
00-README.md                 this file
MANIFEST.json                machine-readable: every group, path, line count, check name
restore-ALL.patch            reverse of 824ff18 — restores all 58 paths at once
groups/*.patch               12 independent per-gate patches
deleted-files/               pristine full copies of all 30 deleted files, byte-identical
                             to their pre-de-gating state (browse or copy in directly,
                             no patching needed)
```

`deleted-files/` is the escape hatch: if a patch ever stops applying because `main` drifted,
copy the file straight in from there — those 30 files were deleted outright, so there is
nothing to merge.
